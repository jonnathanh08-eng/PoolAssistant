# 8 Ball Pool Assistant PRO

Proyecto Android nativo de práctica (Kotlin). Incluye selector de ángulo, potencia, rebotes de referencia y un diagrama de mesa ilustrativo.

## Crear el APK
1. Instala Android Studio en una computadora.
2. Abre esta carpeta como proyecto (Open).
3. Espera a que Gradle sincronice y descargue los componentes Android necesarios.
4. Selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio generará el APK en `app/build/outputs/apk/debug/app-debug.apk`.

Esta app no se conecta al juego, no lee su pantalla y no altera partidas. Es un simulador de práctica independiente.
